﻿using Cibertec.UnitOfWork;
using Microsoft.Owin;
using Microsoft.Owin.Security.OAuth;
using Owin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;

namespace Cibertec.WebApi.App_Start
{
    public static class TokenConfig
    {
        public static void ConfigureOAuth(IAppBuilder app,
                                          HttpConfiguration config)
        {
            var unitOfWork = (IUnitOfWork)config
                .DependencyResolver.GetService(typeof(IUnitOfWork));
            OAuthAuthorizationServerOptions oauthServerOptions =
                new OAuthAuthorizationServerOptions()
                {
                    AllowInsecureHttp = true,
                    TokenEndpointPath = new PathString("/token"),
                    AccessTokenExpireTimeSpan = TimeSpan.FromDays(1),
                    Provider = new SimpleAuthorizationServerProvider(unitOfWork)
                };
            app.UseOAuthAuthorizationServer(oauthServerOptions);
            app.UseOAuthBearerAuthentication(new OAuthBearerAuthenticationOptions());
        }
    }
}
