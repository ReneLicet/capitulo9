﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Cors;
using Cibertec.Models;
using Cibertec.UnitOfWork;
using log4net;

namespace Cibertec.WebApi.Controllers
{
    [RoutePrefix("customer")]
    [EnableCors("*","*","*")]
    public class CustomerController : BaseController
    {
        public CustomerController(IUnitOfWork unit, ILog log) : base(unit, log)
        {
            _log.Info($"{typeof(CustomerController)} in Excecution");
        }
        [Route("{id}")]
        public IHttpActionResult Get(int id) {
            if (id <= 0) return BadRequest();
            return Ok(_unit.Customers.GetById(id));
        }
        [Route("")]
        [HttpPost]
        public IHttpActionResult Post(Customer customer) {
            if (!ModelState.IsValid) return BadRequest(ModelState);
            var id = _unit.Customers.Insert(customer);
            return Ok(new { id = id });
        }

        [Route("")]
        [HttpPut]
        public IHttpActionResult Put(Customer customer) {
            if (!ModelState.IsValid) return BadRequest(ModelState);
            if (!_unit.Customers.Update(customer)) return BadRequest("Incorrect id");
            return Ok(new { status = true });
        }

        [Route("{id}")]
        [HttpDelete]
        public IHttpActionResult Delete(int id) {
            if (id <= 0) return BadRequest();
            var resutl = _unit.Customers.Delete(new Customer { Id = id });
            return Ok(new { delete = true });
        }

        [HttpGet]
        [Route("list")]
        public IHttpActionResult GetList()
        {
            return Ok(_unit.Customers.GetList());
        }
        [HttpGet]
        [AllowAnonymous]
        [Route("error")]
        public IHttpActionResult CreateError() {
            throw new System.Exception("This is a unhanle exception");
        }
    }
}
