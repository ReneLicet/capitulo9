﻿using Cibertec.Models;
using Cibertect.WebApiClient.Code;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace Cibertect.WebApiClient.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
        public string RunWebClient() {
            CibertecWebApiClient client = new CibertecWebApiClient();
            var customer = new Customer
            {
                FirstName = "Barack",
                LastName = "Obama",
                City = "Hawaii",
                Phone = "19999999",
                Country = "USA"
            };

            var customerId = client.PostCustomer(customer);
            var isDeleted = client.DeleteCustomer(customerId);
            var customerList = client.GetCustomers().ToList();
            var message = $"customer created {customerId}, deleted {isDeleted}, total customers{customerList.Count}";
            return message;
        }

        public string RunWebProduct()
        {
            CibertecWebApiProduct product = new CibertecWebApiProduct();
            var producto = new Product
            {
                ProductName = "Product 6",
                SupplierId = 1,
                UnitPrice = 15,
                Package = "producto 6p",
                IsDiscontinued = true
            };

            var productId = product.PostProduct(producto);
            var isDeleted = product.DeleteProduct(productId);
            var productList = product.GetProducts().ToList();
            var message = $"product created {productId}, deleted {isDeleted}, total products{productList.Count}";
            return message;
        }


        public ActionResult RunJqueryClient() {
            return View();
        }
        
    }
}