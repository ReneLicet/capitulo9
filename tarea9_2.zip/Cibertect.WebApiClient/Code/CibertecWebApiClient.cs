﻿using Cibertec.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Cibertect.WebApiClient.Code
{
    public class CibertecWebApiClient
    {
        private const string APIURL = "http://localhost:50517/";
        public IEnumerable<Customer> GetCustomers() {
            IEnumerable<Customer> customers = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIURL);
                var responseTask = client.GetAsync("customer/list");
                responseTask.Wait();
                var result = responseTask.Result;

                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IEnumerable<Customer>>();
                    readTask.Wait();
                    customers = readTask.Result;
                }
                else
                {
                    //Error response received   
                    customers = Enumerable.Empty<Customer>();
                }
            }
            return customers;
        }

        public int PostCustomer(Customer customer)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIURL);
                var responseTask = client.PostAsJsonAsync("customer", customer);
                responseTask.Wait();
                var result = responseTask.Result;

                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<Customer>();
                    readTask.Wait();
                    customer = readTask.Result;     
                }
            }
            return customer.Id;
        }

        public bool DeleteCustomer(int id)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIURL);
                var responseTask = client.DeleteAsync("customer/" + id);
                responseTask.Wait();
                var result = responseTask.Result;

                if (result.IsSuccessStatusCode)
                {
                    return true;
                }
            }
            return false;
        }
    }
}
