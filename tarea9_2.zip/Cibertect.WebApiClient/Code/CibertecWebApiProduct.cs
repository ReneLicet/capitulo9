﻿using Cibertec.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;

namespace Cibertect.WebApiClient.Code
{
    public class CibertecWebApiProduct
    {
        private const string APIURL = "http://localhost:50517/";
        public IEnumerable<Product> GetProducts()
        {
            IEnumerable<Product> products = null;
            using (var product = new HttpClient())
            {
                product.BaseAddress = new Uri(APIURL);
                var responseTask = product.GetAsync("product/list");
                responseTask.Wait();
                var result = responseTask.Result;

                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<IEnumerable<Product>>();
                    readTask.Wait();
                    products = readTask.Result;
                }
                else
                {
                    //Error response received   
                    products = Enumerable.Empty<Product>();
                }
            }
            return products;
        }

        public int PostProduct(Product producto)
        {
            using (var product = new HttpClient())
            {
                product.BaseAddress = new Uri(APIURL);
                var responseTask = product.PostAsJsonAsync("product", producto);
                responseTask.Wait();
                var result = responseTask.Result;

                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<Product>();
                    readTask.Wait();
                    producto = readTask.Result;
                }
            }
            return producto.Id;
        }

        public bool DeleteProduct(int id)
        {
            using (var producto = new HttpClient())
            {
                producto.BaseAddress = new Uri(APIURL);
                var responseTask = producto.DeleteAsync("product/" + id);
                responseTask.Wait();
                var result = responseTask.Result;

                if (result.IsSuccessStatusCode)
                {
                    return true;
                }
            }
            return false;
        }

    }
}